var version_tool = "1.0.5";
var last_updated_time = "2018-03-26 10:00:00";